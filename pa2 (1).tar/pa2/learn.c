#include <stdio.h>
#include <stdlib.h>

double temp1;
int tcol;
int i,y;
//int e,f;

void freememory(double**arr, int rowws){
	int i =0;
	for(i=0;i<rowws;i++){
		free(arr[i]);
	}
	free(arr);
	return;
}
static double ** reduce(int orgC, int col, int j,int pivotC, double **aug,int pivotR,double pivot){
i = pivotC;
   for(y=j; y<col+1;y++){
      if(aug[y][i] != 0){
	temp1 = aug[y][i];
	  while(i<2*(orgC+1)){
	  aug[y][i] = aug[y][i] - (temp1*aug[pivotR][i]);
	  i++;
	  }
	  i = pivotC ;
	}
      } 
  return aug;
}
int i,j,k; 

static double ** multiply( int m1r, int m1c,int m2r,int m2c,double **m1,double **m2){

double **mult = (double**)malloc((m1r)*sizeof(double*)); 
for(i = 0; i<m1r; i++){
  mult[i] = (double*)malloc((m2c)*sizeof(double*));}

double sum = 0; 
for(i = 0; i <m1r; i++){
  for(j=0; j <m2c; j++){
      for(k= 0; k<(m2r); k++){
       sum = sum+(m1[i][k]*m2[k][j]);
      }
      mult[i][j] = sum;	  
      sum= 0; 
  }
}

return mult;
}


int main(int argc, char ** argv){
  FILE *fp; 
  FILE *fp2;
  char *filename = NULL;
  char *filename2 = NULL;
  int row,col,row2;
  int i,j;
 // int k;
  int a,b;
   double pivot; 
  filename = argv[1];
  filename2 = argv[2];
  fp =fopen(filename,"r"); //opens the file
  fp2 = fopen(filename2,"r");
  if(fp ==NULL){
    printf("Empty file\n");
    exit(0);
  }
 if(fp2 == NULL){
    printf("Empty file\n");
    exit(0);
  }



fscanf(fp,"%d",&col);
fscanf(fp,"%d",&row);
fscanf(fp2,"%d",&row2);

double **train = (double**)malloc(row*sizeof(double*));
double **test = (double**)malloc(row2*sizeof(double*));
  
double **X = (double**)malloc(row*sizeof(double*));
double **XT = (double**)malloc((col+1)*sizeof(double*));
double **Inverse = (double**)malloc((col+1)*sizeof(double*)); 
double **identity = (double**)malloc((col+1)*sizeof(double*));
double **aug = (double**)malloc((col+1)*sizeof(double*));
double **y = (double**)malloc(row*sizeof(double*));
double **s2 = (double**)malloc((col+1)*sizeof(double*));
double **weights = (double**)malloc((col+1)*sizeof(double*));

double **final = (double**)malloc((row2)*sizeof(double*));

for(i=0; i<row2; i++){
  final[i] = (double*)malloc(1*sizeof(double*));
}



for(i=0; i<col+1; i++){
  weights[i] = (double*)malloc(1*sizeof(double*));
}
for(i= 0; i<row; i++){
  train[i] = (double*)malloc((col+1)*sizeof(double*));
}
for(i=0; i<row2; i++){
  test[i] = (double*)malloc((col+1)*sizeof(double*));
}
for(i=0; i<col+1; i++){
  s2[i] = (double*)malloc((col+1)*sizeof(double*));
}
for(i = 0; i<row;i++){
  y[i] = (double*)malloc((1*sizeof(double*)));
}
for (i = 0; i<row; i++){
  X[i] = (double*)malloc((col+1)*sizeof(double*));
}
for(i = 0; i<(col+1); i++){
  XT[i] = (double*)malloc(row*sizeof(double*));
}
for(i = 0; i<col+1; i++){
  Inverse[i] = (double*)malloc((col+1)*sizeof(double*));}
for(i = 0; i<col+1; i++){
  identity[i] = (double*)malloc((col+1)*sizeof(double*));
}
for(i=0; i<col+1; i++){
  aug[i] = (double*)malloc((2*(col+1))*sizeof(double*));
}


while(!feof(fp)){    
for(i = 0; i<row; i++){
  for(j = 0; j<(col+1); j++){
  fscanf(fp,"%lf,",&train[i][j]); 
  }
 }
}
while(!feof(fp2)){
for(i = 0; i<row2; i++){
  for(j = 1; j<(col+1); j++){
  fscanf(fp2,"%lf,",&test[i][j]); 
  }
 }

}
  
for(a = 0; a<row2; a++){
  for(b=0; b<1; b++){
    test[a][b] = 1.0000;
  }
}
for(a=0; a<row;a++){
  for(b=0;b<1;b++){
    X[a][b] = 1.00000;
  }
}

for(a=0; a<row; a++){
  for(b=1; b<(col+1); b++){
    X[a][b] = train[a][b-1];
     
  }
}

for(a = 0; a<row; a++){
   y[a][0] = train[a][col];
  }
//FINDING TRANSPOSE

for(i = 0; i <row; i++){
  for(j=0; j<(col+1); j++){
    XT[j][i] = X[i][j];
  }
}

double **tempo = (double**)malloc((col+1)*sizeof(double*)); 
for(i = 0; i<col+1; i++){
  tempo[i] = (double*)malloc((col+1)*sizeof(double*));}

tempo = multiply(col+1,row,row,col+1,XT,X);
for(i = 0; i<col+1; i++){
  for(j=0; j<col+1; j++){
    if(i==j){
      identity[i][j] = 1.00000; 
    }
    else{
      identity[i][j] = 0.0;
    }
  }
}

for(i = 0; i<col+1; i++){
  for(j=0;j<col+1;j++){
    aug[i][j] = tempo[i][j]; 
  }
}
for(i=0; i<col+1; i++){
  for(j=col+1; j<(2*(col+1)); j++){
    aug[i][j] = identity[i][j-(col+1)];
  }
}
 int pivotR,pivotC;
double temp;
for(i = 0; i<col+1; i++){//col
  for(j=0; j<(col+1); j++){//row
   if(j==i){ 
      pivot = aug[j][i];
      pivotR = j;
      pivotC = i;
      temp = pivot;
      if(pivot != 1.0000){
	while(i<2*(col+1)){
	  aug[j][i] = aug[j][i]/temp;
	  i++;
	}
      i = pivotC;
	
      }
      if(pivotR == 0){
	
	reduce(col,col,j+1,pivotC,aug,0,pivot);
      }
      else if (pivotR == (row-1)){
	reduce(col,pivotR,0,pivotC,aug,pivotR,pivot);
      }
      else{
	reduce(col,pivotR-1,0,pivotC,aug,pivotR,pivot);
	reduce(col,col,pivotR+1,pivotC,aug,pivotR,pivot);
      }


    }
  }

}
for(a=0; a<col+1; a++){
  for(b=col+1; b<(2*(col+1)); b++){
    Inverse[a][b-(col+1)]= aug[a][b];
  }
}

s2 = multiply(col+1,col+1,col+1,row,Inverse,XT);

weights = multiply(col+1,row,row,1,s2,y);


final = multiply(row2,col+1,col+1,1,test,weights);
for(a = 0; a<row2; a++){
  for(b=0; b<1; b++){
    printf("%1.0lf\n",final[a][b]);
  }
}


freememory(train,row);
freememory(test,row2);
freememory(X,row);
freememory(XT,col+1);
freememory(Inverse,col+1);
freememory(identity,col+1);
freememory(aug,col+1);
freememory(y,row);
freememory(s2,col+1);
freememory(weights,col+1);
freememory(tempo,col+1);
freememory(final,row2);

return 0; 
}
   
